rm(list = ls(all.names = TRUE))
setwd( paste0(getwd(),"/inst/FR_EolPop_UTF8/") )
#setwd( paste0(getwd(),"/inst/FR_EolPop_ANSI/") )
#setwd( paste0(getwd(),"/inst/EN_EolPop/") )
#setwd("../")
#setwd("./FR_EolPop_ANSI")
getwd()

source("ui.R")
source("server.R")

shinyApp(ui = ui, server = server)

