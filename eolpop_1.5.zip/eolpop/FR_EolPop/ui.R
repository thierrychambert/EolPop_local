rm(list = ls(all.names = TRUE))

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Initial stuff
{
  # Pour v�rifier si tous les packages requis sont install�s (et les installer sinon)
  list.of.packages <- c("shiny", "shinyjs", "shinyBS", "shinyMatrix", "tidyverse", "SHELF",
                        "promises", "future", "ipc", "popbio", "knitr", "kableExtra", "rmarkdown")
  new.packages <- list.of.packages[!(list.of.packages %in% installed.packages()[,"Package"])]
  if(length(new.packages) > 0) install.packages(new.packages)


  ## Load libraries
  library(shiny)
  library(shinyjs)
  library(shinyBS)
  library(shinyMatrix)
  library(tidyverse)
  library(eolpop)
  library(popbio)
  library(knitr)
  library(kableExtra)
  library(rmarkdown)

  library(promises)
  library(future)
  library(ipc)
  plan(multisession)

  options(knitr.table.format = "latex")

  ## Load species list
  species_data <- read.csv("species_list.csv", sep = ";")
  species_list <- unique(as.character(species_data$Species_fr)) %>% sort
  species_list <- c(species_list, "Esp�ce g�n�rique")

}
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~###

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Pre-fill data
{
  ## Data elicitation pre-fill data
  # fatalities
  eli_fatalities <- c(1.0, 2, 5, 8,  0.80,
                      0.2, 0, 3, 6,  0.90,
                      0.2, 2, 4, 10, 0.90,
                      0.1, 1, 3, 7,  0.70)

  # population size
  eli_pop_size <-   c(1.0, 150, 200, 250, 0.80,
                      0.5, 120, 180, 240, 0.90,
                      0.8, 170, 250, 310, 0.90,
                      0.3, 180, 200, 230, 0.70)

  # carrying capacity
  eli_carrying_cap <- c(1.0, 500, 700, 1000, 0.80,
                        0.5, 1000, 1500, 2000, 0.90,
                        0.8, 800, 1200, 1600, 0.90,
                        0.3, 100, 1200, 1500, 0.70)

  # population growth rate
  eli_pop_growth <- c(1.0, -5, -2, 0, 0.95,
                      0.2, -3, 0, 1, 0.90,
                      0.5, -8, -4, -1, 0.90,
                      0.3, -10, -5, -2, 0.70)
}

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~###



###~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~###
##  User Interface
###~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~###
# Define User Interface ########################################################
{ui <- navbarPage(
  "EolPop v1.5",

  # Graphic Design Parameters
  header =
    {
      tags$head(
        tags$style(HTML("

body {
    font-family: 'Roboto', Sans-serif!important;
    background-color: rgb(240, 244, 247) !important;
}
.navbar-default {
    padding-right: 40px;
    padding-left: 40px;
    padding-top: 120px;
    background-image: url(https://mape.cnrs.fr/webapp/images/logo-mape-2.png);
    background-size: 600px;
    background-repeat: no-repeat;
    background-position: left top;
}
.navbar-default .navbar-brand {
    font-size: 40px;
    font-family: 'Roboto', Sans-serif;
    font-weight: 300;
    color:#005697 !important;

}
.navbar>.container-fluid .navbar-brand {
    margin-left: -35px;
}
.container-fluid>.navbar-header {
    padding-top: 10px;
}
.navbar-default .navbar-nav>.active>a{
    background-color: #2898f3 !important;
    border-color: #fff;
    color: #fff!important;
    border-radius: 50px;
    margin:10px;
}
.navbar-default .navbar-nav>li>a{
	background-color: #005697 !important;
    border-color: #fff;
    color: #fff!important;
    border-radius: 50px;
    margin:10px;
}
.navbar-default .navbar-nav>li>a:hover{
    background-color: #2898f3 !important;
    border-color: #fff;
    color: #fff!important;
    border-radius: 50px;
    margin:10px;
}
.navbar-default {
	color:#fff;
    background-color: rgb(240, 244, 247) !important;
    border-color:rgb(240, 244, 247)!important;
}
h2{
	width:100%;
	background-color:#77B82A;
	padding:7px 15px 7px 15px;
	border-radius: 15px;
	margin-bottom:40px;
	margin-top:20px;
	font-size: 30px;
  font-family: 'Roboto', Sans-serif;
  font-weight: 300;
  color:#ffffff !important;
}
.footermape{
	box-shadow: 0px 0px 7px 0px rgb(0 0 0 / 10%);
	background-image: url('https://mape.cnrs.fr/webapp/images/logos.png');
	background-position: center;
	background-size: contain;
	background-repeat: no-repeat;
	background-color:#fff;
	margin-bottom:30px!important;
	margin-top:30px!important;
	display: inline-block!important;
    width: 100%;
    height: 130px;
    content:''!important;
    border:15px #fff solid;
    border-radius: 15px;
}
.well {
    margin-bottom: 15px!important;
    background-color: #fff!important;
    border: 1px solid #fff!important;
    border-radius: 15px!important;
    box-shadow: 0px 0px 7px 0px rgb(0 0 0 / 10%)!important;
}
.btn-default{
	background-color: #005697!important;
	border-color: #fff!important;
	color: #fff!important;
    border-radius: 50px!important;
    border-color:#fff!important;
    padding:10px!important;
    margin-bottom:10px!important;
}
.btn:hover {
    background-color: #2898f3!important;
    border-color: #fff!important;
	color: #fff!important;
    border-radius: 50px!important;
}
.btn-group-xs>.btn, .btn-xs{
	background-color:#cfcfcf!important;
	padding:3px 7px 3px 7px!important;
}
.btn-group-xs>.btn, .btn-xs:focus{
	background-color:#cfcfcf!important;
	padding:3px 7px 3px 7px!important;
}
.btn-group-xs>.btn, .btn-xs:hover{
	background-color:#acacac!important;
	padding:3px 7px 3px 7px!important;
}
.nav-tabs {
	border-color:#fff!important;
    background-color:white!important;
    border-radius:15px!important;
	background-color: #e1e1e2!important;
	border: 15px #005697!important;
    margin:15px!important;
    padding:5px!important;
}
.nav-tabs>li {
	background-color: #e1e1e2!important;
	border: 0!important;

}
.nav-tabs>li.active>a {
    color: #fff!important;
    cursor: default!important;
    background-color: #2898f3!important;
    border: 0px!important;
    border-radius:12px!important;
    border-bottom-color: transparent!important;
}
.nav-tabs>li>a {
	border: 0px!important;
    border-radius:12px!important;
    color:#636363!important;
}
.nav-tabs>li>a:hover {
	color: #fff!important;
    background-color: #c7c7c8!important;
    border: 0px!important;
    border-radius:12px!important;
    border-bottom-color: transparent!important;
        color:#636363!important;
}
.nav-tabs>li>a:focus {
	color: #fff!important;
    background-color: #2898f3!important;
    border: 0px!important;
    border-radius:12px!important;
    border-bottom-color: transparent!important;
	color:#fff!important;
}
.tab-content>.active {
    padding:20px!important;
}
hr {
    margin-bottom:40px!important;
    border: none!important;
}
h4{
	font-weight:700!important;
}
.col-sm-8{
	margin-bottom: 40px!important;
    background-color: #fff!important;
    border: 1px solid #fff!important;
    border-radius: 15px!important;
    box-shadow: 0px 0px 7px 0px rgb(0 0 0 / 10%)!important;
    padding:20px!important;
}
.lien{
	background-color: #909090!important;
	border-color: #fff!important;
	color: #fff!important;
    border-radius: 50px!important;
    border-color:#fff!important;
    padding:10px!important;
}

                    "))
      )},

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~###
# Tab/Page 1 : About ########################################################
{tabPanel(

  "A propos",


  {wellPanel(

    h4("Pr�sentation"),

    p(HTML("<i>EolPop</i> est un outil permettant de quantifier l'<b>impact d�mographique</b>
    des mortalit�s aviaires caus�es par les collisions avec les �oliennes.<br>
    Il s'agit d'un outil d'aide � la d�cision, � vocation <i><b>informative</b></i>.
    Il vise � <i>fournir une �valuation objective</i> des cons�quences de la mortalit�s
         aviaire � l'�chelle des populations.")),

    br(),

    h5(HTML("Cette application a �t� d�velopp�e par
       <a href='https://sites.google.com/view/fr-thierrychambert/home'>Thierry Chambert</a>
       dans le cadre du programme de recherche
            <a href='https://mape.cnrs.fr'>MAPE</a>.")),

    p(strong("Contact: aurelien.besnard@cefe.cnrs.fr")),

    br(),

    p(tags$a(href="https://mape.cnrs.fr/applications/", target="_blank", "Comment utiliser cette application ?", class="lien")),

    br(),

    p(tags$a(href="https://mape.cnrs.fr", target="_blank", "Visiter le site du projet MAPE", class="lien")),



  )}, # End wellpanel #########################################################
  p(class="footermape"),
  p("Avec la participation des op�rateurs �oliens partenaires du projet MAPE"),
  br(),
  h5("Mentions l�gales"),
  p("Propri�taire du site : CNRS, 1919 route de Mende 34090 Montpellier"),
  p("Site internet h�berg� par la plateforme SIE du CEFE"),
  br(),
  p(HTML(
    '<a rel="license" href="http://creativecommons.org/licenses/by-nc-nd/4.0/"><img alt="Licence Creative Commons" style="border-width:0" src="https://i.creativecommons.org/l/by-nc-nd/4.0/88x31.png" /></a><br />Cette oeuvre est mise � disposition selon les termes de la <a rel="license" href="http://creativecommons.org/licenses/by-nc-nd/4.0/">Licence Creative Commons Attribution - Pas d&#39;Utilisation Commerciale - Pas de Modification 4.0 International</a>'
  )
  )


)}, # End Page 1 #########################################################



#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~###
# Tab/Page 2 : Analytical tool #############################################
{tabPanel(
  HTML("Outil d�mographique <i>EolPop</i>"),

  useShinyjs(),
  titlePanel("EolPop : Impact d�mographique des collisions aviaires avec les �oliennes"),


  ###~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~###
  # Head Panel 1 : type of analysis and species
  {wellPanel(
    p("Choix d'analyse et esp�ce", style="font-size:28px"),

    {fluidRow(

      # Select type of analysis : cumulated impacted or not
      {column(width = 4,
              # Choose analysis type (radioButton)
              {radioButtons(inputId = "analysis_choice",
                            label = h4(strong("Type d'analyse"),
                                       bsButton("Q_analysis_choice", label = "", icon = icon("question"), size = "extra-small"),
                                       bsPopover(id = "Q_analysis_choice",
                                                 title = "Choix du type d\\'analyse",
                                                 content = HTML(
                                                   "<b>Impacts non cumul�s</b> : pour analyser l\\'impact d\\'<b>un seul parc �olien</b>. <br><br> <b>Impact cumul�s</b> : pour analyser l\\'impact de <b>plusieurs parcs �oliens</b> (attention : il faudra fournir des valeurs de mortalit�s propres � chaque parc).<br><br> <b>Sc�narios hypoth�tiques</b> : permet d'�valuer plusieurs sc�narios de mortalit�s hypoth�tiques en une seule analyse."
                                                 ),
                                                 placement = "right",
                                                 trigger = "click",
                                                 options = list(container='body')
                                       )
                            ),
                            choices = c("Impacts non cumul�s" = "single_farm",
                                        "Impacts cumul�s" = "cumulated",
                                        "Sc�narios hypoth�tiques" = "multi_scenario"
                            )
              )},

              # Choose species (selectInput)
              {selectInput(inputId = "species_choice",
                           selected = "Aigle de Bonelli", width = '80%',
                           label = h4(strong("S�lectionner une esp�ce"),
                                      bsButton("Q_species_choice", label = "", icon = icon("question"), size = "extra-small"),
                                      bsPopover(id = "Q_species_choice",
                                                title = "Choix de l\\'esp�ce",
                                                content = HTML(
                                                  "N�cessaire pour fixer les valeurs de <b>param�tres d�mographiques</b> (survie, f�condit�). <br><br> La liste fournie correspond � une liste d\\'esp�ces prioritaires. Au besoin, une option \\'esp�ce g�n�rique\\' est disponible � la fin de la liste."
                                                ),
                                                placement = "right",
                                                trigger = "click",
                                                options = list(container='body')
                                      )
                           ),
                           choices = species_list)},

              br(),
              # Show dispersal distances : mean and d = 5%
              h4(strong("Distances de dispersion"),
                 bsButton("Q_dispersal_info", label = "", icon = icon("question"), size = "extra-small"),
                 bsPopover(id = "Q_dispersal_info",
                           title = "Distances de dispersion",
                           content = HTML(
                             "(1) <b>Distance moyenne de dispersion</b> de l\\'esp�ce, estim�e � partir des relations allom�triques publi�es dans l\\'article de Claramunt (2021).<br><br> (2) Distance �quivalente � un <b>taux de dispersion relatif de 3%, 5% et 10%</b>, sous l\\'hypoth�se que la distance de dispersion suit une loi exponentielle.<br><br><u>Reference cit�e</u> : Claramunt, S. (2021). Flight efficiency explains differences in natal dispersal distances in birds. <i>Ecology</i>, e03442."
                           ),
                           placement = "right",
                           trigger = "click",
                           options = list(container='body')
                 )
              ),
              #br(),
              span(textOutput(outputId = "dispersal_mean_info"), style="font-size:14px"),
              br(),
              span(textOutput(outputId = "dispersal_d03p_info"), style="font-size:12px"),
              span(textOutput(outputId = "dispersal_d05p_info"), style="font-size:12px"),
              span(textOutput(outputId = "dispersal_d10p_info"), style="font-size:12px"),

      )}, # close column

      # Show vital rate values (tableOutput)
      {column(width = 4,
              fluidRow(
                h4(strong("Param�tres d�mographiques"),
                   bsButton("Q_vital_rates_info", label = "", icon = icon("question"), size = "extra-small"),
                   bsPopover(id = "Q_vital_rates_info",
                             title = "Param�tres d�mographiques",
                             content = HTML(
                               "Valeurs de <b>survie et f�condit�s par classe d\\'�ge</b>, pour l\\'esp�ce s�lectionn�e. <br><br><b>L\\'�ge 0</b> (ex : Juv 0) correspond � un individu n� dans l\\'ann�e, n\\'ayant <u>pas encore</u> 1 an r�volu.<br><b>L\\'�ge 1</b> correspond � un individu ayant 1 an r�volu, donc dans sa 2<sup>e</sup> ann�e de vie.<br>Etc."
                               #"Valeurs de <b>survie et f�condit�s par classe d\\'�ge</b>, pour l\\'esp�ce s�lectionn�e. <br><br><b>Juv 0</b> correspond � un individu n� dans l\\'ann�e, n\\'ayant <u>pas encore</u> 1 an r�volu.<br><b>Juv 1</b> correspond � un individu ayant 1 an r�volu, donc dans sa 2<sup>e</sup> ann�e de vie.<br>Etc."
                             ),
                             placement = "right",
                             trigger = "click",
                             options = list(container='body')
                   )
                ),
                tableOutput(outputId = "vital_rates_info"),

              ), # close fluidRow


              # Display the intrinsic lambda(i.e., based solely on the Leslie matrix)
              # Output display (intrinsic lambda)
              h5(strong("Taux de croissance intrins�que"),
                 bsButton("Q_lambda0_info", label = "", icon = icon("question"), size = "extra-small"),
                 bsPopover(id = "Q_lambda0_info",
                           title = "Taux de croissance intrins�que",
                           content = HTML(
                             "Taux de croissance bas� seulement sur la matrice de Leslie (survies et f�condit�s de l\\'esp�ce), <b> avant consid�ration de la tendance de population locale</b>. <br><br>Ce taux de croissance est fourni simplement � titre informatif. La valeur qui sera utilis�e dans les simulations correspond au taux de croissance fourni dans la partie \\'Taux de croissance\\'."
                           ),
                           placement = "right",
                           trigger = "click",
                           options = list(container='body')
                 )
              ),
              div(textOutput(outputId = "lambda0_info", inline = TRUE), style = "color:black; font-size:16px"),

              br(),

              span("* Les valeurs marqu�es d'une ast�risque ne sont pas issues de la litt�rature.
                  Elles ont �t� inf�r�es � partir des autres valeurs de param�tres.
                  Il y a donc plus d'incertitude quant � leur exactitude.",
                   style = "color:black; font-size:12px"),


      )}, # close column


      ## Modify vital rates, if needed (actionButton and matrixInput)
      {column(width = 4,
              actionButton(inputId = "button_vital_rates",
                           label = tags$span("Modifier les param�tres d�mographiques",
                                             style = "font-weight: bold; font-size: 18px;")
              ),

              br(" "),
              numericInput(inputId = "vr_mat_number_age_classes",
                           label = "Nombre de classes d'age",
                           value = NA, min = 2, max = Inf, step = 1),

              #br(),
              matrixInput(inputId = "mat_fill_vr",
                          label = "",
                          value = matrix(data = NA, 3, 2,
                                         dimnames = list(c("Juv 0", "Sub 1", "Adulte"), c("Survie", "F�condit�"))),
                          class = "numeric",
                          rows = list(names = TRUE),
                          cols = list(names = TRUE)
              ),

              actionButton(inputId = "button_use_custom_vr",
                           label = tags$span("Appliquer ces param�tres")
              ),

      )}, # close column

    )}, # End fluidRow
  )}, # End wellPanel
  ###~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~###


  ###~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~###
  # Head Panel 2 : Model parameters
  {wellPanel(

    ## Enter parameter values (TITLE)
    {p("Saisie des param�tres", style="font-size:28px",
       bsButton("Q_param_enter", label = "", icon = icon("question"), size = "extra-small"),
       bsPopover(id = "Q_param_enter",
                 title = "Saisie des param�tres pour l\\'analyse",
                 content = HTML(
                   "Cliquer sur les boutons ci-dessous pour saisir les valeurs des quatre param�tres requis pour l\\'analyse : <br>(1) Mortalit�s annuelles, <br>(2) Taille de la population, <br>(3) Tendance de la population, <br>(4) Capacit� de charge."
                 ),
                 placement = "right",
                 trigger = "click",
                 options = list(container='body')
       )
    )},

    {fluidRow(

      ##~~~~~~~~~~~~~~~~~~~~~~~~~
      ##  1. Fatalities
      ##~~~~~~~~~~~~~~~~~~~~~~~~~
      {column(width = 3,

              actionButton(inputId = "button_fatalities", width = '100%',
                           label = tags$span("Mortalit�s annuelles", style = "font-weight: bold; font-size: 18px;")
              ),
              bsPopover(id = "button_fatalities",
                        title = "Mortalit�s annuelles",
                        content = HTML(
                          "Nombre de mortalit�s totales <b><u>annuelles</u> (cad. sur 12 mois) </b> attendues, pour l\\'esp�ce s�lectionn�e, sur chaque parc �olien concern� (somme des mortalit�s attendues sur toutes les �oliennes d\\'un parc)."
                        ),
                        placement = "top",
                        trigger = "hover",
                        options = list(container='body')
              ),

              ### Part for non-cumulated impacts
              # Input type
              {conditionalPanel("output.hide_fatalities",
                                br(),

                                {wellPanel(style = "background:#FFF8DC",
                                           radioButtons(inputId = "fatalities_unit", inline = FALSE,
                                                        label = "Unit�",
                                                        choices = c("Nombre de mortalit�s" = "M",
                                                                    "Taux de mortalit� (%)" = "h"),
                                                        selected = "M"),
                                )}, # close wellPanel 1

                                {wellPanel(style = "background:#F0F8FF",

                                           radioButtons(inputId = "fatalities_input_type",
                                                        label = "Type de saisie",
                                                        choices = c("Intervalle" = "itvl",
                                                                    "Valeurs" = "val",
                                                                    "Elicitation d'expert" = "eli_exp"),
                                                        selected = "itvl"),

                                           # Interval
                                           numericInput(inputId = "fatalities_lower",
                                                        label = "Borne inf�rieure (mortalit�s annuelles)",
                                                        value = 1,
                                                        min = 0, max = Inf, step = 0.5),

                                           numericInput(inputId = "fatalities_upper",
                                                        label = "Borne sup�rieure (mortalit�s annuelles)",
                                                        value = 1,
                                                        min = 0, max = Inf, step = 0.5),

                                           # Values
                                           numericInput(inputId = "fatalities_mean",
                                                        label = "Moyenne (mortalit�s annuelles)",
                                                        value = 1,
                                                        min = 0, max = Inf, step = 0.5),

                                           numericInput(inputId = "fatalities_se",
                                                        label = "Erreur-type (mortalit�s annuelles)",
                                                        value = 0,
                                                        min = 0, max = Inf, step = 0.1),

                                           # Matrix for expert elicitation
                                           numericInput(inputId = "fatalities_number_expert",
                                                        label = "Nombre d'experts",
                                                        value = 4, min = 1, max = Inf, step = 1),

                                           matrixInput(inputId = "fatalities_mat_expert",
                                                       value = matrix(data = eli_fatalities, nrow = 4, ncol = 5,
                                                                      dimnames = list(c("#1", "#2", "#3", "#4"),
                                                                                      c("Poids", "Min", "Best", "Max", "%IC" )),
                                                                      byrow = TRUE),
                                                       class = "numeric",
                                                       rows = list(names = TRUE),
                                                       cols = list(names = TRUE)),

                                           actionButton(inputId = "fatalities_run_expert",
                                                        label = "Utiliser valeurs experts"),

                                           ### Part for cumulated impacts

                                           numericInput(inputId = "farm_number_cumulated",
                                                        label = "Nombre de parcs �oliens",
                                                        value = 3, min = 2, max = Inf, step = 1),

                                           matrixInput(inputId = "fatalities_mat_cumulated",
                                                       label = span("Mortalit�s dans chaque parc",
                                                                    bsButton("Q_fatalities_mat_cumulated", label = "", icon = icon("question"), size = "extra-small"),
                                                                    bsPopover(id = "Q_fatalities_mat_cumulated",
                                                                              title = "Mortalit�s cumul�es",
                                                                              content = HTML(
                                                                                "1 ligne = 1 parc <br><br>Les parcs doivent �tre fournis dans l\\'<b>ordre chronologique</b> de leur mise en service (\\'Ann�e d�but\\'). <br><br>Pour chaque parc, veuillez indiquer la <u>moyenne</u> et l\\'<u>erreur-type</u> du nombre de mortalit�s estim�es, ainsi que son <u>ann�e de mise en service</u>."
                                                                              ),
                                                                              placement = "right",
                                                                              trigger = "click",
                                                                              options = list(container='body')
                                                                    )
                                                       ),
                                                       value = matrix(c(1, 0, 2011,
                                                                        2, 0, 2012,
                                                                        3, 0, 2013),
                                                                      nrow = 3, ncol = 3, byrow = TRUE,
                                                                      dimnames = list(c(paste0("Parc num.", c(1:3))),
                                                                                      c("Valeur centrale",
                                                                                        "Erreur-type",
                                                                                        "Ann�e (d�but)"))),
                                                       class = "numeric",
                                                       rows = list(names = TRUE),
                                                       cols = list(names = TRUE)),


                                           ### Part for "scenarios option"
                                           selectizeInput(inputId = "fatalities_vec_scenario",
                                                          label = HTML(
                                                            "Saisir chaque valeur de mortalit�<br>
                                               (s�parer par un espace)"
                                                          ),
                                                          choices = NULL,
                                                          multiple = TRUE,
                                                          options = list(
                                                            create = TRUE,
                                                            delimiter = ' ',
                                                            create = I("function(input, callback){
                                                              return {
                                                              value: input,
                                                              text: input
                                                            };
                                                          }")
                                                          )
                                           ),






                                )}, # close wellPanel

              )}, # close conditional panel

      )}, # end column "fatalities"

      ###~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~###


      ##~~~~~~~~~~~~~~~~~~~~~~~~~
      ##  2. Population Size
      ##~~~~~~~~~~~~~~~~~~~~~~~~~
      {column(width = 3,

              actionButton(inputId = "button_pop_size", width = '100%',
                           label = tags$span("Taille de la population", style = "font-weight: bold; font-size: 18px;")
              ),
              bsPopover(id = "button_pop_size",
                        title = "Taille de la population",
                        content = HTML(
                          "Effectif de la population cible pour l\\'analyse d\\'impact. <br> Il peut s\\'agir soit du <b>nombre de couples</b>, soit de l\\'<b>effectif total</b> de la population (cad. toutes classes d\\'�ge incluses)."
                        ),
                        placement = "top",
                        trigger = "hover",
                        options = list(container='body')
              ),

              {conditionalPanel("output.hide_pop_size",
                                br(),

                                {wellPanel(style = "background:#FFF8DC",
                                           radioButtons(inputId = "pop_size_unit", inline = FALSE,
                                                        label = "Unit�",
                                                        choices = c("Nombre de couples" = "Npair",
                                                                    "Effectif total" = "Ntotal"),
                                                        selected = "Npair"),
                                )}, # close wellPanel 1

                                {wellPanel(style = "background:#F0F8FF",

                                           radioButtons(inputId = "pop_size_input_type",
                                                        label = "Type de saisie",
                                                        choices = c("Intervalle" = "itvl",
                                                                    "Valeurs" = "val",
                                                                    "Elicitation d'expert" = "eli_exp")),

                                           # Interval
                                           numericInput(inputId = "pop_size_lower",
                                                        label = "Borne inf�rieure (taille population)",
                                                        value = 500,
                                                        min = 0, max = Inf, step = 10),

                                           numericInput(inputId = "pop_size_upper",
                                                        label = "Borne sup�rieure (taille population)",
                                                        value = 500,
                                                        min = 0, max = Inf, step = 10),

                                           # Values
                                           numericInput(inputId = "pop_size_mean",
                                                        label = "Moyenne de la taille de la population",
                                                        value = 500,
                                                        min = 0, max = Inf, step = 50),

                                           numericInput(inputId = "pop_size_se",
                                                        label = "Erreur-type de la taille de la population",
                                                        value = 0,
                                                        min = 0, max = Inf, step = 1),

                                           # Matrix for expert elicitation
                                           numericInput(inputId = "pop_size_number_expert",
                                                        label = "Nombre d'experts",
                                                        value = 4, min = 1, max = Inf, step = 1),

                                           matrixInput(inputId = "pop_size_mat_expert",
                                                       value = matrix(data = eli_pop_size, nrow = 4, ncol = 5,
                                                                      dimnames = list(c("#1", "#2", "#3", "#4"),
                                                                                      c("Poids", "Min", "Best", "Max", "%IC" )),
                                                                      byrow = TRUE),
                                                       class = "numeric",
                                                       rows = list(names = TRUE),
                                                       cols = list(names = TRUE)),

                                           actionButton(inputId = "pop_size_run_expert", label = "Utiliser valeurs experts"),
                                )}, # close wellPanel 2


                                # Display matrix for stable age distribution
                                h5(strong("Effectifs par classe d'�ge")),
                                tableOutput("pop_size_by_age"),

              )}, # close conditional panel

      )}, # end column "pop size"
      ###~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~###


      ##~~~~~~~~~~~~~~~~~~~~~~~~~
      ##  3. Population Growth
      ##~~~~~~~~~~~~~~~~~~~~~~~~~
      {column(width = 3,

              actionButton(inputId = "button_pop_growth", width = '100%',
                           label = tags$span("Taux de croissance", style = "font-weight: bold; font-size: 18px;")
              ),
              bsPopover(id = "button_pop_growth",
                        title = "Taux de croissance",
                        content = HTML(
                          "Taux d\\'accroissement annuel de la population <b>en %</b> : valeur positive pour une population en croissance; valeur <b>n�gative</b> pour une population en <b>d�clin</b> (ex : � -4 � pour un d�clin de 4% par an) ; 0 pour une population stable.<br><br>A d�faut, on pourra juste cocher la <b>tendance globale</b> (d�clin, stabilit� ou croissance) et l\\'intensit� de cette tendance (faible, moyenne, forte)."
                        ),
                        placement = "top",
                        trigger = "hover",
                        options = list(container='body')
              ),

              {conditionalPanel("output.hide_pop_growth",
                                br(),

                                {wellPanel(style = "background:#F0F8FF",

                                           radioButtons(inputId = "pop_growth_input_type",
                                                        label = "Type de saisie",
                                                        choices = c("Intervalle" = "itvl",
                                                                    "Valeurs" = "val",
                                                                    "Elicitation d'expert" = "eli_exp",
                                                                    "Tendance population" = "trend")),
                                           # Interval
                                           numericInput(inputId = "pop_growth_lower",
                                                        label = HTML("Borne inf�rieure<br>(taux d'accroissement en %)"),
                                                        value = -2,
                                                        min = -100, max = Inf, step = 1),

                                           numericInput(inputId = "pop_growth_upper",
                                                        label = HTML("Borne sup�rieure<br>(taux d'accroissement en %)"),
                                                        value = -2,
                                                        min = -100, max = Inf, step = 1),

                                           ## Input values: mean and se
                                           numericInput(inputId = "pop_growth_mean",
                                                        label = "Moyenne (taux d'accroissement en %)",
                                                        value = -2,
                                                        min = -100, max = Inf, step = 1),

                                           numericInput(inputId = "pop_growth_se",
                                                        label = "Erreur-type (aussi en %)",
                                                        value = 0,
                                                        min = 0, max = Inf, step = 0.5),

                                           ## Input expert elicitation: table
                                           numericInput(inputId = "pop_growth_number_expert",
                                                        label = "Nombre d'experts",
                                                        value = 4, min = 1, max = Inf, step = 1),

                                           matrixInput(inputId = "pop_growth_mat_expert",
                                                       value = matrix(data = eli_pop_growth, nrow = 4, ncol = 5,
                                                                      dimnames = list(c("#1", "#2", "#3", "#4"),
                                                                                      c("Poids", "Min", "Best", "Max", "%IC" )),
                                                                      byrow = TRUE),
                                                       class = "numeric",
                                                       rows = list(names = TRUE),
                                                       cols = list(names = TRUE)),

                                           actionButton(inputId = "pop_growth_run_expert", label = "Utiliser valeurs experts"),

                                           ## Input trend: radio buttons
                                           {fluidRow(
                                             # Trend
                                             column(6,
                                                    radioButtons(inputId = "pop_trend",
                                                                 label = "Tendance",
                                                                 choices = c("Croissance" = "growth",
                                                                             "Stable" = "stable",
                                                                             "En d�clin" = "decline")),
                                             ),

                                             # Strength of trend
                                             column(6,
                                                    radioButtons(inputId = "pop_trend_strength",
                                                                 label = "Intensit�",
                                                                 choices = c("Faible" = "weak",
                                                                             "Moyenne" = "average",
                                                                             "Forte" = "strong")),
                                             ),
                                           )}, # close fluidRow

                                           br(),
                                           actionButton(inputId = "button_calibrate_vr", label = "Calibrer survies et f�condit�s"),


                                )}, # close wellPanel

              )}, # close conditional panel

      )}, # end column "pop growth"
      ###~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~###


      ##~~~~~~~~~~~~~~~~~~~~~~~~~
      ##  4. Carrying capacity
      ##~~~~~~~~~~~~~~~~~~~~~~~~~
      {column(width = 3,

              actionButton(inputId = "button_carrying_cap", width = '100%',
                           label = tags$span("Capacit� de charge", style = "font-weight: bold; font-size: 18px;")
              ),

              bsPopover(id = "button_carrying_cap",
                        title = "Capacit� de charge (K)",
                        content = HTML(
                          "La capacit� de charge (K) correspond � la <b>taille maximale que peut atteindre la population</b> dans son environnement et les limites spatiales consid�r�es. <br><br><u>Note:</u> Ce chiffre sera exprim� dans la <b>m�me unit�</b> que la taille de population (cad. nombre de couples ou effectif total). <br>Il n\\'a pas besoin d\\'�tre tr�s pr�cis&nbsp;; il doit simplement fournir un ordre de grandeur de la taille limite au-del� de laquelle la population ne peut plus cro�tre (environnement local �satur�)."
                        ),
                        placement = "top",
                        trigger = "hover",
                        options = list(container='body')
              ),


              {conditionalPanel("output.hide_carrying_cap",
                                br(),

                                {wellPanel(style = "background:#FFF8DC",
                                           span(textOutput(outputId = "carrying_cap_unit_info"), style="font-size:16px"),

                                )}, # close wellPanel 1

                                {wellPanel(style = "background:#F0F8FF",

                                           radioButtons(inputId = "carrying_cap_input_type",
                                                        label = "Type de saisie",
                                                        choices = c("Intervalle" = "itvl",
                                                                    "Valeur" = "val",
                                                                    "Elicitation d'expert" = "eli_exp",
                                                                    "Absence de K" = "no_K")),

                                           # Interval
                                           numericInput(inputId = "carrying_capacity_lower",
                                                        label = "Borne inf�rieure (capacit� de charge)",
                                                        value = 1000,
                                                        min = 0, max = Inf, step = 100),

                                           numericInput(inputId = "carrying_capacity_upper",
                                                        label = "Borne sup�rieure (capacit� de charge)",
                                                        value = 1000,
                                                        min = 0, max = Inf, step = 100),

                                           # Values
                                           numericInput(inputId = "carrying_capacity_mean",
                                                        label = "Moyenne de la capacit� de charge",
                                                        value = 1000,
                                                        min = 0, max = Inf, step = 100),

                                           numericInput(inputId = "carrying_capacity_se",
                                                        label = "Erreur-type de la capacit� de charge",
                                                        value = 0,
                                                        min = 0, max = Inf, step = 50),


                                           # Expert Elicitation Matrix
                                           numericInput(inputId = "carrying_cap_number_expert",
                                                        label = "Nombre d'experts",
                                                        value = 4, min = 1, max = Inf, step = 1),

                                           matrixInput(inputId = "carrying_cap_mat_expert",
                                                       value = matrix(data = eli_carrying_cap, nrow = 4, ncol = 5,
                                                                      dimnames = list(c("#1", "#2", "#3", "#4"),
                                                                                      c("Poids", "Min", "Best", "Max", "%IC" )),
                                                                      byrow = TRUE),
                                                       class = "numeric",
                                                       rows = list(names = TRUE),
                                                       cols = list(names = TRUE)),

                                           actionButton(inputId = "carrying_cap_run_expert", label = "Utiliser valeurs experts"),

                                )}, # close wellPanel 2

              )}, # close conditional panel

      )}, # end column "carrying capacity"
      ###~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~###


    )}, # # End fluidRow

  )}, # # End wellPanel
  ###~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~###



  ###~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~###
  {sidebarLayout(

    ##  Side Panel : Parameter information
    {sidebarPanel(

      p("Valeurs s�lectionn�es", style="font-size:24px",
        bsButton("Q_selected_values", label = "", icon = icon("question"), size = "extra-small"),
        bsTooltip(id = "Q_selected_values",
                  title = "Rappel des valeurs de param�tres actuellement s�lectionn�es.",
                  placement = "right",
                  trigger = "click",
                  options = list(container='body')
        )
      ),

      # Mortalites annuelles
      span("Mortalit�s annuelles", style="font-size:18px; font-weight: bold"),
      shiny::tags$i(textOutput(outputId = "fatalities_unit_info"), style="font-size:15px"),
      span(textOutput(outputId = "fatalities_mean_info"), style="font-size:15px"),
      span(textOutput(outputId = "fatalities_se_info"), style="font-size:15px"),

      br(),
      # Taille de population
      span("Taille de la population", style="font-size:18px; font-weight: bold"),
      shiny::tags$i(textOutput(outputId = "pop_size_unit_info"), style="font-size:15px"),
      span(textOutput(outputId = "pop_size_mean_info"), style="font-size:15px"),
      span(textOutput(outputId = "pop_size_se_info"), style="font-size:15px"),

      br(),
      # Tendance de la population
      span(HTML("Taux de croissance (&lambda;)"), style="font-size:18px; font-weight: bold"),
      span(textOutput(outputId = "pop_growth_mean_info"), style="font-size:15px"),
      span(textOutput(outputId = "pop_growth_se_info"), style="font-size:15px"),

      br(),
      # Capacite de charge
      span("Capacit� de charge", style="font-size:18px; font-weight: bold"),
      shiny::tags$i(textOutput(outputId = "carrying_capacity_unit_info"), style="font-size:15px"),
      span(textOutput(outputId = "carrying_capacity_mean_info"), style="font-size:15px"),
      span(textOutput(outputId = "carrying_capacity_se_info"), style="font-size:15px"),


    )}, # End sidebarPanel


    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    ###  Main Panel

    {mainPanel(
      tabsetPanel(id = NULL, selected = "Impact population",

                  ## Parameter distribution
                  {tabPanel(title = "Distribution param�tres",
                            actionButton("show_ditri_fatalities", label = "Mortalit�s annuelles"),
                            actionButton("show_ditri_pop_size", label = "Taille de la population"),
                            actionButton("show_ditri_pop_growth", label = "Taux de croissance"),
                            actionButton("show_ditri_carrying_cap", label = "Capacit� de charge"),
                            span(textOutput(outputId = "title_distri_plot"), style="font-size:24px; font-weight:bold"),
                            plotOutput(outputId = "distri_plot"),

                  )}, # End tabPanel


                  ## Population Impact : simulations
                  {tabPanel(title = "Impact population",

                            br(),
                            numericInput(inputId = "time_horizon",
                                         label = "Nombre d'ann�es",
                                         value = 30, min = 5, max = Inf, step = 10),

                            br(),
                            numericInput(inputId = "nsim",
                                         label = "Nombre de simulations",
                                         value = 10, min = 0, max = Inf, step = 10),

                            br(),
                            actionButton(inputId = "run", label = "Lancer l'analyse"),
                            actionButton(inputId = "cancel", "Annuler"),
                            actionButton(inputId = "status", "Verifier l'�tat"),
                            actionButton(inputId = 'clear', 'Effacer les r�sultats'),

                            br(),
                            span(textOutput("msg_run"), align = "left", style = "font-weight: bold; font-size: 16px;"),

                            br(" "),
                            span(textOutput("run_time"), align = "left", style = "font-weight: normal; font-size: 12px;"),

                            #hr(),
                            #br(),
                            #actionButton(inputId = "show_results", label = "R�sultats"),
                            #p("R�sultats", style="font-size:28px"),



                  )}, # End tabPanel


                  ## Report
                  {tabPanel(title = "Rapport",
                            br(" "),
                            textAreaInput("intro_report", label = "Contexte de l'�tude",
                                          value = "Analyse r�alis�e dans le cadre de ...", width = "1000px"),

                            br(" "),
                            textAreaInput("def_pop_text", label = "D�limitation de la population",
                                          value = "Veuillez d�crire ici l'approche et les informations utilis�es pour d�limiter la population concern�e par cette �tude d'impact d�mographique",
                                          width = "1000px"),

                            br(" "),
                            downloadButton("report", "Produire un rapport")
                  )} # End tabPanel

      ) # End tabSetPanel
    )} # End mainPanel

  )}, # sidebarLayout



  ###############################################################################################################################
  ## RESULTS
  ###############################################################################################################################
  hr(),

  conditionalPanel("output.hide_RES_TITLE",
                   h1("R�sultats")
  ),

  #hr(),

  ## Results : text
  {sidebarLayout(

    ##  Side Panel
    {conditionalPanel("output.hide_show_CI",
                      {sidebarPanel(
                        ## Choose CI
                        sliderInput("show_CI", label = "Intervalle de confiance (%)", min = 0, max = 100, value = 95, step = 1),
                        hr(),
                      )}, # End sidebarPanel
    )}, # close conditional panel

    #######################################################

    {conditionalPanel("output.hide_results",
                      {mainPanel(

                        # Table : Global impact
                        {column(
                          width = 7,
                          span(textOutput("title_impact_result"), align = "left", style = "font-weight: bold; font-size: 18px;"),
                          strong(span(tableOutput("impact_table"), style="color:blue; font-size:18px", align = "left")),
                        )},

                        # Table : Probability of extinction
                        {column(
                          width = 5,
                          span(textOutput("title_PrExt_result"), align = "left", style = "font-weight: bold; font-size: 18px;"),
                          strong(span(tableOutput("PrExt_table"), style="color:orange; font-size:18px", align = "left")),
                        )},

                      )}, # End mainPanel
    )}, # close conditional panel


  )}, # sidebarLayout


  ###############################################################################################################################
  #hr(),

  ## Results : Graphs
  {sidebarLayout(

    ##  Side Panel
    {conditionalPanel("output.hide_graph_choice",
                      {sidebarPanel(
                        ##
                        ## Choose which graph to show
                        radioButtons("choose_graph", label = h5(strong("Graphique (choix)")),
                                     choices = c(
                                       "Impact final : densit� de probabilit�" = "show_PDF",
                                       "Impact final : probabilit� cumul�e" = "show_ECDF",
                                       "Impact relatif au cours du temps" = "show_impact_time",
                                       "Projections d�mographiques" = "show_demog_proj"
                                     )),

                        br(),
                        ## Choose "scenario" to show
                        radioButtons("show_scenario", label = h5(strong("Choix du sc�nario")),
                                     choices = c("all")),

                        br(),
                        hr(),
                        br(),

                        ## Choose "quantile" : level of under-estimation risk (1 - QT)
                        conditionalPanel("output.hide_risk_A",
                                         wellPanel(style = "background:#F0F8FF",
                                                   sliderInput("risk_A", label = "Risque (%) de sous-estimation de l'impact", min = 0, max = 100, value = 5, step = 0.5),

                                                   br(),

                                                   h5(strong("Valeur de l'impact au quantile choisi")),
                                                   #, style = "font-weight: bold; font-size: 18px;")
                                                   span(verbatimTextOutput("quantile_impact_result"), align = "left", style = "font-weight: bold; font-size: 18px;"),
                                         )
                        ), # close conditional panel

                        ##
                      )}, # End sidebarPanel
    )}, # close conditional panel

    #######################################################

    {conditionalPanel("output.hide_graphs",
                      {mainPanel(
                        ## Graph : Probability Density (PDF)
                        {conditionalPanel("output.hide_graph_PDF",
                                          tags$h4(textOutput("title_PDF_plot"), align = "center"),
                                          plotOutput("PDF_plot", width = "100%", height = "550px"),
                        )}, # close conditional panel

                        ## Graph : Cumulative Distibution (ECDF)
                        {conditionalPanel("output.hide_graph_ECDF",
                                          tags$h4(textOutput("title_ECDF_plot"), align = "center"),
                                          plotOutput("ECDF_plot", width = "100%", height = "550px"),
                        )}, # close conditional panel

                        ## Graph : Relative Impact over time
                        {conditionalPanel("output.hide_graph_impact_time",
                                          tags$h4(textOutput("title_impact_plot"), align = "center"),
                                          plotOutput("impact_plot", width = "100%", height = "550px"),
                        )}, # close conditional panel

                        ## Graph : Population trajectory (pop size over time)
                        {conditionalPanel("output.hide_graph_demog_proj",
                                          tags$h4(textOutput("title_traj_plot"), align = "center"),
                                          br(),

                                          wellPanel(
                                            span(textOutput("warning_traj_plot"), align = "left", style = "font-size: 14px;"),
                                          ),

                                          br(" "),
                                          radioButtons(inputId = "age_class_show",
                                                       label = "Classes d'�ge � inclure sur le graphe",
                                                       choices = c("Tous �ges sauf juv�niles" = "NotJuv0",
                                                                   "Tous �ges, y compris juv�niles" = "all",
                                                                   "Nombre de couples" = "pairs"),
                                                       inline = TRUE
                                          ),
                                          plotOutput("traj_plot", width = "100%", height = "550px")
                        )}, # close conditional panel

                      )}, # End mainPanel
    )}, # close conditional panel (of mainpanel)








  )}, # sidebarLayout


  p(class="footermape"),
  p("Avec la participation des op�rateurs �oliens partenaires du projet MAPE"),
  br(),
  h5("Mentions l�gales"),
  p("Propri�taire du site : CNRS, 1919 route de Mende 34090 Montpellier"),
  p("Site internet h�berg� par la plateforme SIE du CEFE"),
  br(),
  p(HTML(
    '<a rel="license" href="http://creativecommons.org/licenses/by-nc-nd/4.0/"><img alt="Licence Creative Commons" style="border-width:0" src="https://i.creativecommons.org/l/by-nc-nd/4.0/88x31.png" /></a><br />Cette oeuvre est mise � disposition selon les termes de la <a rel="license" href="http://creativecommons.org/licenses/by-nc-nd/4.0/">Licence Creative Commons Attribution - Pas d&#39;Utilisation Commerciale - Pas de Modification 4.0 International</a>'
  )
  )

)} # End Page 2 ###################################################


)} # End "NavBarPage ###################################################

# End UI #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~###

